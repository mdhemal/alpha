<?php
function alpha_child_assets() {
	wp_enqueue_style( 'parent-style', get_parent_theme_file_uri('/style.css'), null, '1.0.0', false );
}
add_action("wp_enqueue_scrpts", "alpha_child_assets");